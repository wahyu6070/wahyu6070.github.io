---
layout: post
title:  "Firmware Only Asus Zenfone Max Pro M2 (X01BD)"
date:   2021-12-16 17:32:07 +0100
lang: en
categories: Android
permalink: /:categories/:year/:month/:day/:title:output_ext
---

This time I will various firmware only on the Asus Zenfone Max Pro M2, the firmware is updated from Asus stock which was ported as flashable by the developer Wahyu6070 so that it can be installed on TWRP.

This firmware is very important even more than the kernel as the main component of the Android OS.

This firmware functions like the Linux kernel, namely connecting from hardware to software with a low coding language, even lower than the kernel. So this will connect from core hardware such as networks, internet connections to the Linux kernel/Android OS.


## What are the advantages of installing firmware?

- We can update drivers from the network/internet so that it is faster and more stable.
- Can improve hardware performance to make it more efficient
- Can be used by developers to add support to the latest Android version.

## how to install 

- wipe /data /cache /system /vendor
- Install firmware only
- install rom
- reboot system

## Link

Make sure you download it correctly and according to what your ROM requires, because if it is wrong there is a risk of being completely bricked/dead.

[pling](https://www.pling.com/p/2118197/)


